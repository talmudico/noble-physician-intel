import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import DataTable from '../shared/DataTable';

export default function UtilizationTab({ physician }) {
  const { data: claims = [] } = useQuery({
    queryKey: ['claims-by-drug', physician?.npi],
    queryFn: () => base44.entities.ClaimsByDrug.filter({ physician_npi: physician.npi }),
    enabled: !!physician?.npi,
  });

  const columns = [
    { label: 'Drug', key: 'drug_name', render: (row) => <span className="font-medium">{row.drug_name}</span> },
    { label: 'J-Code', key: 'j_code', render: (row) => <span className="font-mono text-xs text-muted-foreground">{row.j_code}</span> },
    { label: 'Order Rank', key: 'order_rank' },
    { label: 'Dx Rank', key: 'diagnosis_rank' },
    { label: 'Total Claims', key: 'total_claims', render: (row) => <span className="font-semibold">{row.total_claims}</span> },
    { label: 'FFS Claims', key: 'medicare_ffs_claims' },
    { label: 'Total Pts', key: 'total_patients' },
    { label: 'FFS Pts', key: 'medicare_ffs_patients' },
    { label: 'MA Pts', key: 'ma_patients' },
    { label: 'Medicaid Pts', key: 'medicaid_patients' },
    { label: 'Comm Pts', key: 'commercial_patients' },
    { label: 'Other Pts', key: 'other_patients' },
    { label: 'Quarter', key: 'quarter' },
  ];

  return (
    <DataTable
      title="Drug Utilization (Noble Infusion Therapies Only)"
      columns={columns}
      data={claims}
      exportFilename={`utilization_${physician?.npi}`}
      emptyMessage="No utilization data available. Import CMS Part B data to populate."
    />
  );
}