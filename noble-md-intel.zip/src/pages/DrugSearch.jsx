import React, { useState, useMemo } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Pill, Filter, User, ArrowRight } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import DataTable from '../components/shared/DataTable';

export default function DrugSearch() {
  const [selectedDrug, setSelectedDrug] = useState('');
  const [countyFilter, setCountyFilter] = useState('');
  const [zipFilter, setZipFilter] = useState('');

  const { data: drugMap = [] } = useQuery({
    queryKey: ['drug-map'],
    queryFn: () => base44.entities.DrugMap.list('-drug_name', 200),
  });

  const { data: allClaims = [] } = useQuery({
    queryKey: ['all-claims-for-drug', selectedDrug],
    queryFn: () => {
      if (!selectedDrug) return [];
      return base44.entities.ClaimsByDrug.filter({ drug_name: selectedDrug });
    },
    enabled: !!selectedDrug,
  });

  const { data: allPhysicians = [] } = useQuery({
    queryKey: ['all-physicians'],
    queryFn: () => base44.entities.Physician.list('-created_date', 500),
  });

  // Build a map of NPI -> physician for quick lookup
  const physicianMap = useMemo(() => {
    const map = {};
    allPhysicians.forEach(p => { map[p.npi] = p; });
    return map;
  }, [allPhysicians]);

  // Merge claims with physician data and apply geo filters
  const results = useMemo(() => {
    return allClaims
      .map(claim => {
        const doc = physicianMap[claim.physician_npi];
        if (!doc) return null;
        return { ...claim, physician: doc };
      })
      .filter(Boolean)
      .filter(item => {
        if (countyFilter && countyFilter !== 'all' && item.physician.county?.toLowerCase() !== countyFilter.toLowerCase()) return false;
        if (zipFilter && !item.physician.zip_code?.startsWith(zipFilter)) return false;
        return true;
      })
      .sort((a, b) => (b.total_claims || 0) - (a.total_claims || 0));
  }, [allClaims, physicianMap, countyFilter, zipFilter]);

  const counties = useMemo(() => {
    const set = new Set();
    allPhysicians.forEach(p => { if (p.county) set.add(p.county); });
    return Array.from(set).sort();
  }, [allPhysicians]);

  const resultColumns = [
    {
      label: 'Physician', key: 'physician_name',
      render: (row) => (
        <Link to={`/physician/${row.physician.id}`} className="flex items-center gap-2 hover:text-primary transition-colors">
          <User className="w-3.5 h-3.5 text-muted-foreground" />
          <span className="font-medium">{row.physician.first_name} {row.physician.last_name}</span>
        </Link>
      )
    },
    { label: 'NPI', key: 'npi', render: (row) => <span className="font-mono text-xs text-muted-foreground">{row.physician_npi}</span> },
    { label: 'Specialty', key: 'specialty', render: (row) => row.physician.specialty },
    { label: 'Practice', key: 'practice', render: (row) => row.physician.practice_group },
    { label: 'City', key: 'city', render: (row) => row.physician.city },
    { label: 'County', key: 'county', render: (row) => row.physician.county },
    { label: 'Total Claims', key: 'total_claims', render: (row) => <span className="font-semibold">{row.total_claims}</span> },
    { label: 'FFS Claims', key: 'medicare_ffs_claims' },
    { label: 'Total Pts', key: 'total_patients' },
    { label: 'MA Pts', key: 'ma_patients' },
    { label: 'Medicaid Pts', key: 'medicaid_patients' },
    { label: 'Comm Pts', key: 'commercial_patients' },
  ];

  return (
    <div className="p-8 max-w-7xl mx-auto">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center">
            <Pill className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-foreground tracking-tight">Reverse Drug Search</h1>
            <p className="text-sm text-muted-foreground">Find every physician prescribing a specific drug in your target area</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-card rounded-xl border border-border p-5 mb-6">
        <div className="flex items-center gap-2 mb-4">
          <Filter className="w-4 h-4 text-muted-foreground" />
          <span className="text-sm font-semibold text-foreground">Search Filters</span>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Drug</label>
            <Select value={selectedDrug} onValueChange={setSelectedDrug}>
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="Select a drug..." />
              </SelectTrigger>
              <SelectContent>
                {drugMap.map(drug => (
                  <SelectItem key={drug.id} value={drug.drug_name}>
                    {drug.drug_name} ({drug.j_code})
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">County</label>
            <Select value={countyFilter} onValueChange={setCountyFilter}>
              <SelectTrigger className="bg-background">
                <SelectValue placeholder="All counties" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Counties</SelectItem>
                {counties.map(c => (
                  <SelectItem key={c} value={c}>{c}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div>
            <label className="text-xs font-medium text-muted-foreground mb-1.5 block">Zip Code</label>
            <Input
              placeholder="Filter by zip..."
              value={zipFilter}
              onChange={(e) => setZipFilter(e.target.value)}
              className="bg-background"
            />
          </div>
        </div>
      </div>

      {/* Results */}
      {selectedDrug ? (
        <>
          <div className="flex items-center gap-2 mb-4">
            <Badge className="bg-primary/10 text-primary border-0 text-xs">{selectedDrug}</Badge>
            <span className="text-sm text-muted-foreground">{results.length} prescriber{results.length !== 1 ? 's' : ''} found</span>
          </div>
          <DataTable
            columns={resultColumns}
            data={results}
            exportFilename={`drug_search_${selectedDrug}`}
            emptyMessage={`No physicians found prescribing ${selectedDrug} in the selected area.`}
          />
        </>
      ) : (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Pill className="w-7 h-7 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground">Select a drug to see all prescribing physicians in your area</p>
        </div>
      )}
    </div>
  );
}