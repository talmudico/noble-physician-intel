import React, { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Search, User, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';

export default function PhysicianSearch() {
  const [searchTerm, setSearchTerm] = useState('');
  const [query, setQuery] = useState('');

  const { data: results = [], isLoading } = useQuery({
    queryKey: ['physician-search', query],
    queryFn: async () => {
      if (!query) return [];
      const all = await base44.entities.Physician.list('-created_date', 200);
      const q = query.toLowerCase();
      return all.filter(p =>
        p.npi?.includes(q) ||
        p.last_name?.toLowerCase().includes(q) ||
        p.first_name?.toLowerCase().includes(q) ||
        `${p.first_name} ${p.last_name}`.toLowerCase().includes(q)
      );
    },
    enabled: !!query,
  });

  const handleSearch = (e) => {
    e.preventDefault();
    setQuery(searchTerm.trim());
  };

  return (
    <div className="p-8 max-w-6xl mx-auto">
      {/* Hero search section */}
      <div className="text-center mb-12 mt-8">
        <h1 className="text-3xl font-bold text-foreground tracking-tight">Physician Intelligence</h1>
        <p className="text-muted-foreground mt-2 text-base">
          Search any physician by name or NPI to view patient population, utilization, and referral patterns.
        </p>
        <form onSubmit={handleSearch} className="mt-8 flex items-center gap-3 max-w-xl mx-auto">
          <div className="relative flex-1">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search by physician name or NPI number..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 text-base bg-card border-border"
            />
          </div>
          <Button type="submit" className="h-12 px-6" disabled={!searchTerm.trim()}>
            Search
          </Button>
        </form>
      </div>

      {/* Results */}
      {isLoading && (
        <div className="flex justify-center py-12">
          <div className="w-6 h-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
        </div>
      )}

      {query && !isLoading && results.length === 0 && (
        <div className="text-center py-12">
          <p className="text-muted-foreground">No physicians found for "{query}"</p>
          <p className="text-sm text-muted-foreground mt-1">Try searching by NPI number or a different name.</p>
        </div>
      )}

      {results.length > 0 && (
        <div className="space-y-2">
          <p className="text-sm text-muted-foreground mb-4">{results.length} result{results.length !== 1 ? 's' : ''} found</p>
          {results.map((physician) => (
            <Link
              key={physician.id}
              to={`/physician/${physician.id}`}
              className="flex items-center justify-between p-4 bg-card border border-border rounded-xl hover:border-primary/30 hover:shadow-sm transition-all group"
            >
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                  <User className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="font-semibold text-foreground group-hover:text-primary transition-colors">
                    {physician.first_name} {physician.last_name}
                  </p>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground mt-0.5">
                    <span className="font-mono">NPI: {physician.npi}</span>
                    {physician.specialty && <span>• {physician.specialty}</span>}
                    {physician.city && <span>• {physician.city}, {physician.state}</span>}
                  </div>
                </div>
              </div>
              <ArrowRight className="w-4 h-4 text-muted-foreground group-hover:text-primary transition-colors" />
            </Link>
          ))}
        </div>
      )}

      {!query && (
        <div className="text-center py-16">
          <div className="w-16 h-16 bg-muted rounded-2xl flex items-center justify-center mx-auto mb-4">
            <Search className="w-7 h-7 text-muted-foreground" />
          </div>
          <p className="text-muted-foreground">Enter a physician name or NPI number to get started</p>
        </div>
      )}
    </div>
  );
}